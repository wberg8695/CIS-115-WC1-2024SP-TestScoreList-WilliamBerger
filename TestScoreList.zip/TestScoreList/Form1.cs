﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestScoreList
{
    public partial class TestScoreList : Form
    {
        public TestScoreList()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void CalcButton_Click(object sender, EventArgs e)
        {
            string error = "Error";
            int total, average;
            int[,] scores = new int[8, 2];
            scores[0, 0] = Convert.ToInt32(scoreIn1.Text);
            scores[1, 0] = Convert.ToInt32(scoreIn2.Text);
            scores[2, 0] = Convert.ToInt32(scoreIn3.Text);
            scores[3, 0] = Convert.ToInt32(scoreIn4.Text);
            scores[4, 0] = Convert.ToInt32(scoreIn5.Text);
            scores[5, 0] = Convert.ToInt32(scoreIn6.Text);
            scores[6, 0] = Convert.ToInt32(scoreIn7.Text);
            scores[7, 0] = Convert.ToInt32(scoreIn8.Text);
            total = scores[0, 0] + scores[1, 0] + scores[2, 0] + scores[3, 0]
                + scores[4, 0] + scores[5, 0] + scores[6, 0] + scores[7, 0];
            average = total / 8;
            scores[0, 1] = scores[0, 0] - average;
            scores[1, 1] = scores[1, 0] - average;
            scores[2, 1] = scores[2, 0] - average;
            scores[3, 1] = scores[3, 0] - average;
            scores[4, 1] = scores[4, 0] - average;
            scores[5, 1] = scores[5, 0] - average;
            scores[6, 1] = scores[6, 0] - average;
            scores[7, 1] = scores[7, 0] - average;
            if (scores[0, 0] >= 0 && scores[0, 0] <= 100)
                if (scores[1, 0] >= 0 && scores[1, 0] <= 100)
                    if (scores[2, 0] >= 0 && scores[2, 0] <= 100)
                        if (scores[3, 0] >= 0 && scores[3, 0] <= 100)
                            if (scores[4, 0] >= 0 && scores[4, 0] <= 100)
                                if (scores[5, 0] >= 0 && scores[5, 0] <= 100)
                                    if (scores[6, 0] >= 0 && scores[6, 0] <= 100)
                                        if (scores[7, 0] >= 0 && scores[7, 0] <= 100)
                                        {
                                            distLabel1.Text = Convert.ToString(scores[0, 1]);
                                            distLabel2.Text = Convert.ToString(scores[1, 1]);
                                            distLabel3.Text = Convert.ToString(scores[2, 1]);
                                            distLabel4.Text = Convert.ToString(scores[3, 1]);
                                            distLabel5.Text = Convert.ToString(scores[4, 1]);
                                            distLabel6.Text = Convert.ToString(scores[5, 1]);
                                            distLabel7.Text = Convert.ToString(scores[6, 1]);
                                            distLabel8.Text = Convert.ToString(scores[7, 1]);
                                            avgOut.Text = Convert.ToString(average);
                                        }
            else
                                        {
                                            distLabel1.Text = error;
                                            distLabel2.Text = error;
                                            distLabel3.Text = error;
                                            distLabel4.Text = error;
                                            distLabel5.Text = error;
                                            distLabel6.Text = error;
                                            distLabel7.Text = error;
                                            distLabel8.Text = error;
                                        }
        }
    }
}