﻿namespace TestScoreList
{
    partial class TestScoreList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.scoreIn1 = new System.Windows.Forms.TextBox();
            this.scoreIn3 = new System.Windows.Forms.TextBox();
            this.scoreIn5 = new System.Windows.Forms.TextBox();
            this.scoreIn7 = new System.Windows.Forms.TextBox();
            this.scoreIn2 = new System.Windows.Forms.TextBox();
            this.scoreIn4 = new System.Windows.Forms.TextBox();
            this.scoreIn6 = new System.Windows.Forms.TextBox();
            this.scoreIn8 = new System.Windows.Forms.TextBox();
            this.instLabel = new System.Windows.Forms.Label();
            this.calcButton = new System.Windows.Forms.Button();
            this.distLabel1 = new System.Windows.Forms.Label();
            this.distLabel2 = new System.Windows.Forms.Label();
            this.avgLabel = new System.Windows.Forms.Label();
            this.avgOut = new System.Windows.Forms.Label();
            this.distLabel3 = new System.Windows.Forms.Label();
            this.distLabel4 = new System.Windows.Forms.Label();
            this.distLabel5 = new System.Windows.Forms.Label();
            this.distLabel6 = new System.Windows.Forms.Label();
            this.distLabel7 = new System.Windows.Forms.Label();
            this.distLabel8 = new System.Windows.Forms.Label();
            this.distTitle = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // scoreIn1
            // 
            this.scoreIn1.Location = new System.Drawing.Point(65, 128);
            this.scoreIn1.Name = "scoreIn1";
            this.scoreIn1.Size = new System.Drawing.Size(100, 22);
            this.scoreIn1.TabIndex = 0;
            // 
            // scoreIn3
            // 
            this.scoreIn3.Location = new System.Drawing.Point(205, 128);
            this.scoreIn3.Name = "scoreIn3";
            this.scoreIn3.Size = new System.Drawing.Size(100, 22);
            this.scoreIn3.TabIndex = 1;
            // 
            // scoreIn5
            // 
            this.scoreIn5.Location = new System.Drawing.Point(346, 128);
            this.scoreIn5.Name = "scoreIn5";
            this.scoreIn5.Size = new System.Drawing.Size(100, 22);
            this.scoreIn5.TabIndex = 2;
            // 
            // scoreIn7
            // 
            this.scoreIn7.Location = new System.Drawing.Point(491, 128);
            this.scoreIn7.Name = "scoreIn7";
            this.scoreIn7.Size = new System.Drawing.Size(100, 22);
            this.scoreIn7.TabIndex = 3;
            // 
            // scoreIn2
            // 
            this.scoreIn2.Location = new System.Drawing.Point(65, 181);
            this.scoreIn2.Name = "scoreIn2";
            this.scoreIn2.Size = new System.Drawing.Size(100, 22);
            this.scoreIn2.TabIndex = 4;
            // 
            // scoreIn4
            // 
            this.scoreIn4.Location = new System.Drawing.Point(205, 181);
            this.scoreIn4.Name = "scoreIn4";
            this.scoreIn4.Size = new System.Drawing.Size(100, 22);
            this.scoreIn4.TabIndex = 5;
            // 
            // scoreIn6
            // 
            this.scoreIn6.Location = new System.Drawing.Point(346, 181);
            this.scoreIn6.Name = "scoreIn6";
            this.scoreIn6.Size = new System.Drawing.Size(100, 22);
            this.scoreIn6.TabIndex = 6;
            // 
            // scoreIn8
            // 
            this.scoreIn8.Location = new System.Drawing.Point(491, 181);
            this.scoreIn8.Name = "scoreIn8";
            this.scoreIn8.Size = new System.Drawing.Size(100, 22);
            this.scoreIn8.TabIndex = 7;
            // 
            // instLabel
            // 
            this.instLabel.AutoSize = true;
            this.instLabel.Location = new System.Drawing.Point(270, 90);
            this.instLabel.Name = "instLabel";
            this.instLabel.Size = new System.Drawing.Size(114, 16);
            this.instLabel.TabIndex = 8;
            this.instLabel.Text = "Enter Test Scores";
            // 
            // calcButton
            // 
            this.calcButton.Location = new System.Drawing.Point(629, 156);
            this.calcButton.Name = "calcButton";
            this.calcButton.Size = new System.Drawing.Size(91, 23);
            this.calcButton.TabIndex = 9;
            this.calcButton.Text = "Calculate";
            this.calcButton.UseVisualStyleBackColor = true;
            this.calcButton.Click += new System.EventHandler(this.CalcButton_Click);
            // 
            // distLabel1
            // 
            this.distLabel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.distLabel1.Location = new System.Drawing.Point(62, 289);
            this.distLabel1.Name = "distLabel1";
            this.distLabel1.Size = new System.Drawing.Size(100, 23);
            this.distLabel1.TabIndex = 10;
            // 
            // distLabel2
            // 
            this.distLabel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.distLabel2.Location = new System.Drawing.Point(62, 324);
            this.distLabel2.Name = "distLabel2";
            this.distLabel2.Size = new System.Drawing.Size(100, 23);
            this.distLabel2.TabIndex = 11;
            // 
            // avgLabel
            // 
            this.avgLabel.AutoSize = true;
            this.avgLabel.Location = new System.Drawing.Point(246, 223);
            this.avgLabel.Name = "avgLabel";
            this.avgLabel.Size = new System.Drawing.Size(59, 16);
            this.avgLabel.TabIndex = 12;
            this.avgLabel.Text = "Average";
            // 
            // avgOut
            // 
            this.avgOut.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.avgOut.Location = new System.Drawing.Point(346, 223);
            this.avgOut.Name = "avgOut";
            this.avgOut.Size = new System.Drawing.Size(100, 23);
            this.avgOut.TabIndex = 13;
            // 
            // distLabel3
            // 
            this.distLabel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.distLabel3.Location = new System.Drawing.Point(205, 289);
            this.distLabel3.Name = "distLabel3";
            this.distLabel3.Size = new System.Drawing.Size(100, 23);
            this.distLabel3.TabIndex = 14;
            // 
            // distLabel4
            // 
            this.distLabel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.distLabel4.Location = new System.Drawing.Point(205, 323);
            this.distLabel4.Name = "distLabel4";
            this.distLabel4.Size = new System.Drawing.Size(100, 23);
            this.distLabel4.TabIndex = 15;
            // 
            // distLabel5
            // 
            this.distLabel5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.distLabel5.Location = new System.Drawing.Point(346, 289);
            this.distLabel5.Name = "distLabel5";
            this.distLabel5.Size = new System.Drawing.Size(100, 23);
            this.distLabel5.TabIndex = 16;
            // 
            // distLabel6
            // 
            this.distLabel6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.distLabel6.Location = new System.Drawing.Point(346, 323);
            this.distLabel6.Name = "distLabel6";
            this.distLabel6.Size = new System.Drawing.Size(100, 23);
            this.distLabel6.TabIndex = 17;
            // 
            // distLabel7
            // 
            this.distLabel7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.distLabel7.Location = new System.Drawing.Point(491, 288);
            this.distLabel7.Name = "distLabel7";
            this.distLabel7.Size = new System.Drawing.Size(100, 23);
            this.distLabel7.TabIndex = 18;
            // 
            // distLabel8
            // 
            this.distLabel8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.distLabel8.Location = new System.Drawing.Point(491, 324);
            this.distLabel8.Name = "distLabel8";
            this.distLabel8.Size = new System.Drawing.Size(100, 23);
            this.distLabel8.TabIndex = 19;
            // 
            // distTitle
            // 
            this.distTitle.AutoSize = true;
            this.distTitle.Location = new System.Drawing.Point(255, 261);
            this.distTitle.Name = "distTitle";
            this.distTitle.Size = new System.Drawing.Size(152, 16);
            this.distTitle.TabIndex = 20;
            this.distTitle.Text = "Distance From Average:";
            // 
            // TestScoreList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(761, 417);
            this.Controls.Add(this.distTitle);
            this.Controls.Add(this.distLabel8);
            this.Controls.Add(this.distLabel7);
            this.Controls.Add(this.distLabel6);
            this.Controls.Add(this.distLabel5);
            this.Controls.Add(this.distLabel4);
            this.Controls.Add(this.distLabel3);
            this.Controls.Add(this.avgOut);
            this.Controls.Add(this.avgLabel);
            this.Controls.Add(this.distLabel2);
            this.Controls.Add(this.distLabel1);
            this.Controls.Add(this.calcButton);
            this.Controls.Add(this.instLabel);
            this.Controls.Add(this.scoreIn8);
            this.Controls.Add(this.scoreIn6);
            this.Controls.Add(this.scoreIn4);
            this.Controls.Add(this.scoreIn2);
            this.Controls.Add(this.scoreIn7);
            this.Controls.Add(this.scoreIn5);
            this.Controls.Add(this.scoreIn3);
            this.Controls.Add(this.scoreIn1);
            this.Name = "TestScoreList";
            this.Text = "Test Scores List";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox scoreIn1;
        private System.Windows.Forms.TextBox scoreIn3;
        private System.Windows.Forms.TextBox scoreIn5;
        private System.Windows.Forms.TextBox scoreIn7;
        private System.Windows.Forms.TextBox scoreIn2;
        private System.Windows.Forms.TextBox scoreIn4;
        private System.Windows.Forms.TextBox scoreIn6;
        private System.Windows.Forms.TextBox scoreIn8;
        private System.Windows.Forms.Label instLabel;
        private System.Windows.Forms.Button calcButton;
        private System.Windows.Forms.Label distLabel1;
        private System.Windows.Forms.Label distLabel2;
        private System.Windows.Forms.Label avgLabel;
        private System.Windows.Forms.Label avgOut;
        private System.Windows.Forms.Label distLabel3;
        private System.Windows.Forms.Label distLabel4;
        private System.Windows.Forms.Label distLabel5;
        private System.Windows.Forms.Label distLabel6;
        private System.Windows.Forms.Label distLabel7;
        private System.Windows.Forms.Label distLabel8;
        private System.Windows.Forms.Label distTitle;
    }
}

